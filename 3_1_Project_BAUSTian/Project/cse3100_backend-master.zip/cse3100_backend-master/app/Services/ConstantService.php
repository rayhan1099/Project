<?php
/**
 * This file contains constants used in the application
 */
namespace App\Services;

class ConstantService
{
    const CONTACT_CHANNEL_TYPE_PROFESSIONAL_ACTIVE = 1;
    const CONTACT_CHANNEL_TYPE_PROFESSIONAL_OLD = 2;
    const CONTACT_CHANNEL_TYPE_EDUCATION_ACTIVE = 3;
    const CONTACT_CHANNEL_TYPE_EDUCATION_OLD = 4;
    const CONTACT_CHANNEL_TYPE_ = 1;
    /*const CONTACT_CHANNEL_TYPE_PROFESSIONAL = 1;
    const CONTACT_CHANNEL_TYPE_PROFESSIONAL = 1;
    const CONTACT_CHANNEL_TYPE_PROFESSIONAL = 1;
    const CONTACT_CHANNEL_TYPE_PROFESSIONAL = 1;*/

}
