import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-site-post',
  templateUrl: './site-post.page.html',
  styleUrls: ['./site-post.page.scss'],
})
export class SitePostPage implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
