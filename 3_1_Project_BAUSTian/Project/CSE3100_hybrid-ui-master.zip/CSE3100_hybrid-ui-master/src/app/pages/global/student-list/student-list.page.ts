import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.page.html',
  styleUrls: ['./student-list.page.scss'],
})
export class StudentListPage implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
