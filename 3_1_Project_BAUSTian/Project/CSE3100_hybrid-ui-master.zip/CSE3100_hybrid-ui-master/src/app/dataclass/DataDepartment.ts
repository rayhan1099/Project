export class DataDepartment {
  id: number;
  name: string;
  name_short: string;
  description: string;
  birth_date: string;
  icon: string;
  backdrop: string;
  external_link: string;
  //"updated_at","name", "description", "birth_date", "icon","backdrop","external_link","created_at"
}
