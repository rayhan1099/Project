export const environment = {
  production: true,
  apiUrl: 'https://baustian.herokuapp.com/api/',
  siteRoot: 'https://baustian.herokuapp.com/',
  appName: 'BAUSTian',
  appDescription: '',
};
